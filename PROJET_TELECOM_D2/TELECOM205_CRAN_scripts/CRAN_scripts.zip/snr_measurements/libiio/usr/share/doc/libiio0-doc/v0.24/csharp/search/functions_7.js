var searchData=
[
  ['read_110',['read',['../classiio_1_1Attr.html#ab72e4d43a446dba46b79e73c5744f42d',1,'iio.Attr.read()'],['../classiio_1_1Channel.html#a4539e8e210e3f94f9121cf7e0fbad457',1,'iio.Channel.read()'],['../classiio_1_1IOBuffer.html#a804281513f552fd8e6570b9a826301a2',1,'iio.IOBuffer.read()']]],
  ['read_5fbool_111',['read_bool',['../classiio_1_1Attr.html#a65fc421c1d058a28a7f9c4447ae6c955',1,'iio::Attr']]],
  ['read_5fdouble_112',['read_double',['../classiio_1_1Attr.html#a49505a94b503df2c16e27c2265ae855b',1,'iio::Attr']]],
  ['read_5flong_113',['read_long',['../classiio_1_1Attr.html#a62af2e28fdc64d0e1818d2b98d476de7',1,'iio::Attr']]],
  ['refill_114',['refill',['../classiio_1_1IOBuffer.html#a8a02e05c727fa0a7e8579e5a3122646e',1,'iio::IOBuffer']]],
  ['reg_5fread_115',['reg_read',['../classiio_1_1Device.html#a2b67eb64e1094bca59468f177f6c039e',1,'iio::Device']]],
  ['reg_5fwrite_116',['reg_write',['../classiio_1_1Device.html#aa02e1587a188ed02956a033b488576d1',1,'iio::Device']]]
];
