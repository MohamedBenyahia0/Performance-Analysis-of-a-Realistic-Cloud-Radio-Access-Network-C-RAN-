var searchData=
[
  ['id_131',['id',['../classiio_1_1Channel.html#af94fab980145dfe7b17b9d8a4e94e815',1,'iio.Channel.id()'],['../classiio_1_1Device.html#a5d206eae4628dc18fdfac1e515674cdc',1,'iio.Device.id()']]]
];
