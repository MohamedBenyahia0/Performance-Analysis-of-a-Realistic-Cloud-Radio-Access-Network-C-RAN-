var classiio_1_1ScanContext =
[
    [ "get_dns_sd_backend_contexts", "classiio_1_1ScanContext.html#a097cc76f6b3f5630c0e17db97884bc36", null ],
    [ "get_local_backend_contexts", "classiio_1_1ScanContext.html#a3a7e6bbee822fc27f6917a8c20390f9b", null ],
    [ "get_usb_backend_contexts", "classiio_1_1ScanContext.html#a7f05f475f3f8c6ed8a9bb6118b42d52b", null ]
];