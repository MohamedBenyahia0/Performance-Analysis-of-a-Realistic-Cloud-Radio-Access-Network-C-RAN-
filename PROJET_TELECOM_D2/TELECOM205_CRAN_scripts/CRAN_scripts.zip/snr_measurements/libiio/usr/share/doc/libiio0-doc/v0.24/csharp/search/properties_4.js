var searchData=
[
  ['label_144',['label',['../classiio_1_1Device.html#a3342153fd26e43b710dd33b17cb126fc',1,'iio::Device']]]
];
