var namespaces_dup =
[
    [ "iio", "namespaceiio.html", null ]
];