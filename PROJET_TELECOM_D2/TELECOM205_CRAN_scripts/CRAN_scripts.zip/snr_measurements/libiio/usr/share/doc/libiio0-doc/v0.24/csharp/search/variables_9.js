var searchData=
[
  ['xml_137',['xml',['../classiio_1_1Context.html#a9f9eb26f85fc6b41ba10902a7782b88a',1,'iio::Context']]]
];
