var searchData=
[
  ['name_49',['name',['../classiio_1_1Attr.html#a81a2ccfc71ea989abaa178b98bebbf78',1,'iio.Attr.name()'],['../classiio_1_1Channel.html#a57bb7c9c27737dfe72b4bccc08d5c128',1,'iio.Channel.name()'],['../classiio_1_1Context.html#a83dd7d2ff7f2269eb4d4546179060954',1,'iio.Context.name()'],['../classiio_1_1Device.html#ab1cd5f216aed88ebe52f17556a4488f0',1,'iio.Device.name()']]]
];
