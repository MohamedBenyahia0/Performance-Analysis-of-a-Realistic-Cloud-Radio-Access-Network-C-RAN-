var searchData=
[
  ['attrs_124',['attrs',['../classiio_1_1Channel.html#a8c293243f2ca9ea86da1e633b5441bd9',1,'iio.Channel.attrs()'],['../classiio_1_1Device.html#ae2176fa2b6259f9c120a825f518c4066',1,'iio.Device.attrs()']]]
];
