var searchData=
[
  ['push_51',['push',['../classiio_1_1IOBuffer.html#a407ef31bb34719b2f3808c4cc399d1d1',1,'iio.IOBuffer.push(uint samples_count)'],['../classiio_1_1IOBuffer.html#afbcd902a71b548a92bfb6c96484310c0',1,'iio.IOBuffer.push()']]]
];
