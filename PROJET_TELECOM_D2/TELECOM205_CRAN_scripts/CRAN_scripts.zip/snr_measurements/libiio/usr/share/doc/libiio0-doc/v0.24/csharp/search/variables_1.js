var searchData=
[
  ['channels_125',['channels',['../classiio_1_1Device.html#a060ce06a0516ccc7468196e44fb30b00',1,'iio::Device']]],
  ['circular_126',['circular',['../classiio_1_1IOBuffer.html#aec8134fcdf4c68d0a6e3e54d380fe585',1,'iio::IOBuffer']]]
];
