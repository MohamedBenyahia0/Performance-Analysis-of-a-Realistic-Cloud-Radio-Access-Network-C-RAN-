var searchData=
[
  ['samples_5fcount_135',['samples_count',['../classiio_1_1IOBuffer.html#a4b1116135bcf1442b980f07ac32b92ca',1,'iio::IOBuffer']]],
  ['scan_5felement_136',['scan_element',['../classiio_1_1Channel.html#a0a9079a13b55719bfa36b8d041883ecd',1,'iio::Channel']]]
];
